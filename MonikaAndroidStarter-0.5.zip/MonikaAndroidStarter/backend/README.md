# Backend de Monika Companion 0.3

Este backend ya tiene una integración real con la **Responses API de OpenAI**, pero solo funcionará cuando configures tu propia clave de API en el servidor. La suscripción de ChatGPT y el uso de la API son servicios separados; la API puede generar cargos.

## Requisitos

- Python 3.10 o posterior.
- Una clave de API creada por el titular de la cuenta y con facturación/permisos configurados.
- Conexión a internet desde el equipo que ejecuta el backend.

**No compartas tu clave en el chat ni la pongas en la APK.** Si eres menor, pide a un adulto de confianza que revise la configuración y cualquier posible coste antes de habilitar la API.

## Ejecutar en un equipo de desarrollo

Linux/macOS:

```bash
export OPENAI_API_KEY="tu_clave_va_aqui"
export OPENAI_MODEL="gpt-4.1-mini"
python3 server.py
```

Windows PowerShell:

```powershell
$env:OPENAI_API_KEY="tu_clave_va_aqui"
$env:OPENAI_MODEL="gpt-4.1-mini"
python server.py
```

Prueba de estado: `GET http://127.0.0.1:8765/health`.
La ruta de chat es `POST /chat` y espera `{"messages":[{"role":"user","content":"Hola"}]}`. Devuelve `{"reply":"..."}`.

Puedes personalizar la personalidad desde el servidor con la variable `MONIKA_INSTRUCTIONS`. El backend limita el historial y el tamaño de cada mensaje, no registra el texto de las conversaciones y solicita `store: false` a la API. Eso no sustituye la política de privacidad del proveedor ni convierte el almacenamiento local de la app en almacenamiento cifrado.

## Importante antes de conectarlo desde el móvil

El servidor escucha en `127.0.0.1`, solo accesible desde el propio equipo. **No cambies a `0.0.0.0` ni lo publiques directamente en internet.** Para usarlo desde el teléfono hace falta desplegarlo en un servicio HTTPS con autenticación, límites de uso y protección contra abuso. Esas protecciones de producción aún no están implementadas en este prototipo.
