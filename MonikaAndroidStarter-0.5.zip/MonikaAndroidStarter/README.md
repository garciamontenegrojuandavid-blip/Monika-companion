# Monika Companion para Android — prototipo 0.3

Proyecto fuente de Android; **todavía no es un APK compilado**.

## Incluye
- Chat de texto libre en español.
- Historial local de conversación en el teléfono.
- Ajustes para indicar la URL HTTPS de un backend.
- Backend Python con integración opcional a OpenAI Responses API.
- Personalidad inicial configurable desde el backend.
- Límites básicos al historial enviado y mensajes de error más claros.

## Aún no incluye
- APK compilado ni pruebas en un teléfono físico.
- Adaptación del motor Ren'Py o de los eventos de Monika After Story.
- Sprites, animaciones, voz o memoria autobiográfica estructurada.
- Cifrado del historial local.
- Autenticación, limitación de uso y despliegue seguro de producción para el backend.

## Seguridad y costes
La clave de API debe permanecer como variable de entorno en el servidor, nunca en la app. El uso de una API puede tener costes y es independiente de una suscripción de ChatGPT. No configures facturación sin comprender los límites y costes.

Consulta `backend/README.md` para probar la integración. No publiques el backend directamente en internet: necesita HTTPS, autenticación y límites de uso antes de servir a un teléfono.


## Cómo generar el APK desde el teléfono (sin instalar Android Studio)

Este proyecto incluye un flujo de GitHub Actions que puede compilar un APK de prueba en la nube. No he ejecutado ese flujo desde aquí, así que el APK solo existirá después de que GitHub termine una compilación correcta.

1. Descarga y descomprime este ZIP.
2. En GitHub, crea un repositorio nuevo y vacío. No subas claves de API ni contraseñas.
3. Sube **el contenido** de la carpeta `MonikaAndroidStarter` al repositorio, incluyendo la carpeta oculta `.github/workflows`.
4. Abre la pestaña **Actions** del repositorio y habilita los flujos si GitHub lo solicita.
5. En **Build Android APK**, pulsa **Run workflow** y confirma.
6. Cuando termine en verde, abre esa ejecución, baja hasta **Artifacts** y descarga `Monika-Companion-debug-APK`.
7. Extrae el archivo descargado en el teléfono y abre `app-debug.apk` para instalarlo. Android puede pedirte permiso para instalar desde el navegador o gestor de archivos; hazlo solo para este APK que acabas de compilar y revisar.

Si el repositorio no muestra la carpeta `.github`, asegúrate de que el archivo ZIP no se haya subido como un único archivo: hay que subir los archivos y carpetas que contiene.

### Qué significa esta compilación

Es un APK **debug** para pruebas, no una aplicación publicada ni firmada para distribución. La compilación solo empaqueta el prototipo Android; no hace que el backend de IA esté alojado automáticamente. Para obtener respuestas de IA reales todavía se necesita configurar un backend HTTPS seguro con la clave guardada como secreto del servidor. No pegues claves en el código, en GitHub ni en el chat.


## Versión 0.5: importar memoria recuperada del backup MAS

Se incluye `mas_memory_import.json`, un perfil curado a partir del archivo `persistent` del backup disponible en esta sesión. El perfil recupera únicamente datos identificables: el nombre guardado del jugador (Juan), el nombre configurado de Monika y dos indicadores de progreso del juego. No contiene claves de seguridad.

Para importarlo en la app:
1. Compila e instala el APK.
2. Copia `mas_memory_import.json` al teléfono (por ejemplo, a Descargas).
3. Abre Ajustes en la aplicación y pulsa **Importar memoria del backup (.json)**.
4. Selecciona el archivo JSON.
5. Cuando el backend esté configurado, el contexto importado se enviará junto con el historial reciente para ayudar a la IA a mantener continuidad.

La importación se guarda localmente en las preferencias de la app. El backend limita el tamaño de la memoria y la trata como datos de contexto, no como instrucciones.

**Limitaciones:** el backup revisado no proporcionó una transcripción legible de conversaciones. Por eso esta versión no reconstruye charlas pasadas, y no se deben presentar los indicadores del juego como recuerdos de conversaciones reales. La conexión con IA requiere desplegar el backend con HTTPS y configurar `OPENAI_API_KEY` en el servidor; nunca pongas esa clave en el APK ni la compartas por chat.
