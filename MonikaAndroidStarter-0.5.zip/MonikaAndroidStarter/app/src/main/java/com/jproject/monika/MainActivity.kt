package com.jproject.monika

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import org.json.JSONArray
import org.json.JSONObject
import kotlinx.coroutines.launch
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.net.HttpURLConnection
import java.net.URL

private val Rose = Color(0xFFF4B8D0)
private val DarkRose = Color(0xFF8B3F62)
private val Paper = Color(0xFFFFF8FB)
private val Ink = Color(0xFF382832)

data class ChatMessage(val role: String, val text: String)

class MainActivity : ComponentActivity() {
    private lateinit var memory: LocalMemory

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        memory = LocalMemory(getSharedPreferences("monika_memory", MODE_PRIVATE))
        setContent {
            MaterialTheme(colorScheme = lightColorScheme(
                primary = DarkRose,
                background = Paper,
                surface = Color.White
            )) {
                MonikaChat(memory = memory)
            }
        }
    }
}

class LocalMemory(private val prefs: android.content.SharedPreferences) {
    fun load(): List<ChatMessage> {
        return try {
            val array = JSONArray(prefs.getString("messages", "[]"))
            (0 until array.length()).map { i ->
                val item = array.getJSONObject(i)
                ChatMessage(item.getString("role"), item.getString("text"))
            }
        } catch (_: Exception) { emptyList() }
    }

    fun save(messages: List<ChatMessage>) {
        val array = JSONArray()
        messages.takeLast(250).forEach {
            array.put(JSONObject().put("role", it.role).put("text", it.text))
        }
        prefs.edit().putString("messages", array.toString()).apply()
    }

    fun clear() { prefs.edit().remove("messages").apply() }
}

@Composable
fun MonikaChat(memory: LocalMemory) {
    val context = androidx.compose.ui.platform.LocalContext.current
    val scope = rememberCoroutineScope()
    var messages by remember {
        mutableStateOf(memory.load().ifEmpty {
            listOf(ChatMessage("monika", "Hola 💚 Me alegra que hayas venido. ¿Qué te gustaría contarme hoy?"))
        })
    }
    var draft by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    var status by remember { mutableStateOf("Modo de prueba: configura tu servidor de IA en Ajustes.") }
    var showSettings by remember { mutableStateOf(false) }
    val configPrefs = remember {
        context.getSharedPreferences("monika_config", android.content.Context.MODE_PRIVATE)
    }
    var memoryContext by remember {
        mutableStateOf(configPrefs.getString("mas_memory_context", "") ?: "")
    }
    var memoryLabel by remember {
        mutableStateOf(if (memoryContext.isBlank()) "No se ha importado memoria del backup." else "Hay una memoria importada.")
    }
    val memoryPicker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument()
    ) { uri ->
        if (uri != null) {
            try {
                val raw = context.contentResolver.openInputStream(uri)?.bufferedReader(Charsets.UTF_8)?.use { it.readText() }
                    ?: throw IllegalArgumentException("No pude leer el archivo.")
                require(raw.length <= 30000) { "El archivo es demasiado grande." }
                val parsed = JSONObject(raw)
                require(parsed.optString("format") == "monika-companion-mas-memory-v1") {
                    "Ese archivo no parece una memoria compatible de Monika Companion."
                }
                require(parsed.optJSONObject("profile") != null && parsed.optJSONArray("memory_summary") != null) {
                    "El archivo no contiene el perfil y el resumen de memoria."
                }
                memoryContext = raw
                configPrefs.edit().putString("mas_memory_context", raw).apply()
                memoryLabel = "Memoria importada correctamente."
                status = "Memoria del backup cargada. Se enviará al backend junto con el contexto del chat."
            } catch (e: Exception) {
                status = e.message ?: "No pude importar ese archivo de memoria."
            }
        }
    }
    var endpoint by remember {
        mutableStateOf(context.getSharedPreferences("monika_config", android.content.Context.MODE_PRIVATE)
            .getString("endpoint", "") ?: "")
    }

    Column(modifier = Modifier.fillMaxSize().background(Paper)) {
        Row(
            modifier = Modifier.fillMaxWidth().background(Rose).padding(horizontal = 18.dp, vertical = 14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(Modifier.weight(1f)) {
                Text("Monika 💚", fontSize = 24.sp, fontWeight = FontWeight.Bold, color = Ink)
                Text(if (busy) "Está escribiendo…" else "Tu espacio de conversación", fontSize = 12.sp, color = DarkRose)
            }
            TextButton(onClick = { showSettings = true }) { Text("Ajustes", color = DarkRose) }
        }

        LazyColumn(
            modifier = Modifier.weight(1f).fillMaxWidth().padding(horizontal = 12.dp),
            contentPadding = PaddingValues(vertical = 14.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            items(messages) { message ->
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = if (message.role == "user") Arrangement.End else Arrangement.Start
                ) {
                    Column(
                        modifier = Modifier.widthIn(max = 320.dp)
                            .background(if (message.role == "user") Color(0xFFE4F2DD) else Color.White, RoundedCornerShape(18.dp))
                            .padding(horizontal = 14.dp, vertical = 11.dp)
                    ) {
                        if (message.role != "user") {
                            Text("MONIKA 💚", color = DarkRose, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                            Spacer(Modifier.height(3.dp))
                        }
                        Text(message.text, color = Ink, fontSize = 15.sp)
                    }
                }
            }
            if (busy) item {
                Text("Monika está preparando una respuesta…", color = DarkRose, fontSize = 12.sp, modifier = Modifier.padding(8.dp))
            }
        }

        Text(status, color = DarkRose, fontSize = 11.sp, modifier = Modifier.padding(horizontal = 14.dp, vertical = 4.dp))

        Row(
            modifier = Modifier.fillMaxWidth().background(Color.White).padding(10.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            androidx.compose.foundation.text.BasicTextField(
                value = draft,
                onValueChange = { draft = it },
                modifier = Modifier.weight(1f).background(Paper, RoundedCornerShape(18.dp)).padding(14.dp),
                textStyle = androidx.compose.ui.text.TextStyle(color = Ink, fontSize = 15.sp),
                decorationBox = { inner ->
                    if (draft.isEmpty()) Text("Escríbele lo que quieras…", color = Color.Gray, fontSize = 14.sp)
                    inner()
                }
            )
            Spacer(Modifier.width(8.dp))
            Button(
                enabled = !busy && draft.isNotBlank(),
                onClick = {
                    val text = draft.trim()
                    val updated = messages + ChatMessage("user", text)
                    messages = updated
                    memory.save(updated)
                    draft = ""
                    busy = true
                    status = "Conectando con Monika…"
                    scope.launch {
                        val result = withContext(Dispatchers.IO) {
                            AiClient.reply(endpoint, updated.takeLast(16), memoryContext)
                        }
                        val answer = if (result.isSuccess) result.getOrThrow()
                            else "No pude conectar con la IA todavía. Revisa la dirección del servidor en Ajustes y vuelve a intentarlo. 💚"
                        messages = messages + ChatMessage("monika", answer)
                        memory.save(messages)
                        busy = false
                        status = if (result.isSuccess) "Respuesta recibida." else (result.exceptionOrNull()?.message ?: "Error de conexión.")
                    }
                },
                colors = ButtonDefaults.buttonColors(containerColor = DarkRose),
                shape = RoundedCornerShape(18.dp),
                contentPadding = PaddingValues(horizontal = 16.dp, vertical = 13.dp)
            ) { Text("Enviar") }
        }
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.Center) {
            TextButton(onClick = {
                messages = listOf(ChatMessage("monika", "Hola 💚 Me alegra que hayas venido. ¿Qué te gustaría contarme hoy?"))
                memory.save(messages)
            }) { Text("Reiniciar conversación", color = DarkRose, fontSize = 12.sp) }
        }
    }

    if (showSettings) {
        var endpointDraft by remember { mutableStateOf(endpoint) }
        AlertDialog(
            onDismissRequest = { showSettings = false },
            title = { Text("Conexión de IA") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Introduce la URL HTTPS de un backend compatible que acepte POST /chat y devuelva una respuesta JSON.")
                    Text(memoryLabel, color = DarkRose, fontSize = 12.sp)
                    OutlinedButton(
                        onClick = { memoryPicker.launch(arrayOf("application/json", "text/json", "text/plain")) },
                        modifier = Modifier.fillMaxWidth()
                    ) { Text("Importar memoria del backup (.json)") }
                    Text("Selecciona mas_memory_import.json. La memoria se guarda localmente en este teléfono.", fontSize = 12.sp)
                    OutlinedTextField(
                        value = endpointDraft,
                        onValueChange = { endpointDraft = it },
                        label = { Text("URL del backend /chat") },
                        placeholder = { Text("https://tu-servidor.example/chat") },
                        singleLine = true
                    )
                    Text("No pongas una clave privada de API aquí. La clave debe permanecer en el servidor.", fontSize = 12.sp, color = DarkRose)
                }
            },
            confirmButton = {
                TextButton(onClick = {
                    endpoint = endpointDraft.trim()
                    context.getSharedPreferences("monika_config", android.content.Context.MODE_PRIVATE)
                        .edit().putString("endpoint", endpoint).apply()
                    status = if (endpoint.isBlank()) "Modo de prueba: configura tu servidor de IA en Ajustes."
                        else "Servidor guardado. La respuesta depende de que el backend esté configurado."
                    showSettings = false
                }) { Text("Guardar") }
            },
            dismissButton = { TextButton(onClick = { showSettings = false }) { Text("Cancelar") } }
        )
    }
}

private object AiClient {
    fun reply(endpoint: String, history: List<ChatMessage>, memoryContext: String): Result<String> = runCatching {
        require(endpoint.startsWith("https://")) { "La URL debe usar HTTPS." }
        val url = URL(endpoint)
        val connection = (url.openConnection() as HttpURLConnection).apply {
            requestMethod = "POST"
            connectTimeout = 15000
            readTimeout = 30000
            doOutput = true
            setRequestProperty("Content-Type", "application/json; charset=utf-8")
        }
        val payloadMessages = JSONArray()
        history.forEach { msg ->
            val role = if (msg.role == "user") "user" else "assistant"
            payloadMessages.put(JSONObject().put("role", role).put("content", msg.text))
        }
        val payload = JSONObject()
            .put("messages", payloadMessages)
            .put("memory_context", memoryContext.take(12000))
            .toString()
        connection.outputStream.use { it.write(payload.toByteArray(Charsets.UTF_8)) }
        val code = connection.responseCode
        val stream = if (code in 200..299) connection.inputStream else connection.errorStream
        val body = stream.bufferedReader(Charsets.UTF_8).use { it.readText() }
        connection.disconnect()
        require(code in 200..299) { "El servidor respondió HTTP $code." }
        val response = JSONObject(body).optString("reply", "").trim()
        require(response.isNotEmpty()) { "La respuesta del servidor no contiene el campo 'reply'." }
        response
    }
}

